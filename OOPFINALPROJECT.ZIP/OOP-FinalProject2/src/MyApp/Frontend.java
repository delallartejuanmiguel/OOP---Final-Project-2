package MyApp;

import MyLib.Bookable;
import MyLib.FlightManager;
import MyLib.Transport;

import javax.swing.*;
import java.awt.*;

/**
 * Frontend extends JFrame (Inheritance).
 * Uses FlightManager.getInstance() — Singleton Design Pattern.
 * Interacts with seats via Bookable interface — Polymorphism.
 */
public class Frontend extends JFrame {

    private final FlightManager manager = FlightManager.getInstance();

    public Frontend() {
        setTitle("Flight Booking & Management System");
        setSize(520, 460);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        showMenuPanel();
    }

    private void showMenuPanel() {
        JPanel outer = new JPanel(new BorderLayout(10, 10));
        outer.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        JLabel title = new JLabel("Flight Booking & Management System", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 16));
        outer.add(title, BorderLayout.NORTH);

        JPanel btnPanel = new JPanel(new GridLayout(4, 1, 10, 10));
        JButton viewSeatsBtn  = new JButton("View Available Seats");
        JButton bookSeatBtn   = new JButton("Book / Reserve Seat");
        JButton reportBtn     = new JButton("Generate Report");
        JButton exitBtn       = new JButton("Exit");

        btnPanel.add(viewSeatsBtn);
        btnPanel.add(bookSeatBtn);
        btnPanel.add(reportBtn);
        btnPanel.add(exitBtn);
        outer.add(btnPanel, BorderLayout.CENTER);

        setContentPane(outer);
        revalidate();

        viewSeatsBtn.addActionListener(e -> showAvailableSeats());
        bookSeatBtn .addActionListener(e -> showBookingDialog());
        reportBtn   .addActionListener(e -> showReportDialog());
        exitBtn     .addActionListener(e -> System.exit(0));
    }

    // ---------------------------------------------------------------
    // View Available Seats — user specifies flight, seat class, price
    // ---------------------------------------------------------------
    private void showAvailableSeats() {
        String[] flightNumbers = manager.getFlightNumbers();
        JComboBox<String> flightBox = new JComboBox<>(flightNumbers);

        String[] classes = {"All", "Business", "Economy"};
        JComboBox<String> classBox = new JComboBox<>(classes);

        JTextField maxPriceField = new JTextField("99999");

        JPanel panel = new JPanel(new GridLayout(3, 2, 8, 8));
        panel.add(new JLabel("Flight Number:"));
        panel.add(flightBox);
        panel.add(new JLabel("Seat Class:"));
        panel.add(classBox);
        panel.add(new JLabel("Max Ticket Price (PHP):"));
        panel.add(maxPriceField);

        int result = JOptionPane.showConfirmDialog(this, panel,
                "Search Available Seats", JOptionPane.OK_CANCEL_OPTION);

        if (result != JOptionPane.OK_OPTION) return;

        int flightIdx = flightBox.getSelectedIndex();
        String selectedClass = (String) classBox.getSelectedItem();
        double maxPrice;

        try {
            maxPrice = Double.parseDouble(maxPriceField.getText().trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid price entered.");
            return;
        }

        // First filter by class, then filter that result by price
        String byClass = manager.getAvailableSeatsByClass(flightIdx, selectedClass);
        if (byClass.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No available seats matching your criteria.");
            return;
        }

        // Secondary price filter applied line-by-line on result
        Transport flight = manager.getFlight(flightIdx);
        StringBuilder filtered = new StringBuilder();
        for (int i = 0; i < 20; i++) {
            Bookable seat = flight.getSeat(i);
            boolean classMatch = selectedClass.equals("All") || seat.getSeatClass().equals(selectedClass);
            if (seat.isAvailable() && classMatch && seat.getPrice() <= maxPrice) {
                filtered.append(seat.getInfo());
            }
        }

        String display = filtered.toString();
        if (display.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No available seats matching your criteria.");
            return;
        }

        JTextArea area = new JTextArea(15, 45);
        area.setText("Flight: " + flightNumbers[flightIdx]
                + "  |  Class: " + selectedClass
                + "  |  Max Price: PHP " + maxPrice + "\n"
                + "─".repeat(60) + "\n" + display);
        area.setEditable(false);
        area.setFont(new Font("Monospaced", Font.PLAIN, 12));

        JOptionPane.showMessageDialog(this, new JScrollPane(area),
                "Available Seats", JOptionPane.INFORMATION_MESSAGE);
    }

    // ---------------------------------------------------------------
    // Book / Reserve Seat
    // ---------------------------------------------------------------
    private void showBookingDialog() {
        String[] flightNumbers = manager.getFlightNumbers();
        JComboBox<String> flightBox = new JComboBox<>(flightNumbers);

        String[] classes = {"Business (Seats 1-5, PHP 5000)", "Economy (Seats 6-20, PHP 2000)"};
        JComboBox<String> classBox = new JComboBox<>(classes);

        JTextField seatField = new JTextField();
        JTextField nameField = new JTextField();
        String[] options = {"Reserve", "Book"};

        JPanel panel = new JPanel(new GridLayout(5, 2, 8, 8));
        panel.add(new JLabel("Flight Number:"));
        panel.add(flightBox);
        panel.add(new JLabel("Seat Class (reference):"));
        panel.add(classBox);
        panel.add(new JLabel("Seat Number (1–20):"));
        panel.add(seatField);
        panel.add(new JLabel("Passenger Name:"));
        panel.add(nameField);
        panel.add(new JLabel(""));  // spacer
        panel.add(new JLabel(""));

        int result = JOptionPane.showOptionDialog(this, panel,
                "Book / Reserve Seat", JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE, null,
                options, options[0]);

        if (result < 0) return;

        int flightIdx = flightBox.getSelectedIndex();
        int seatNum;

        try {
            seatNum = Integer.parseInt(seatField.getText().trim()) - 1;
            if (seatNum < 0 || seatNum >= 20) throw new NumberFormatException();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid seat number. Enter a number between 1 and 20.");
            return;
        }

        String passengerName = nameField.getText().trim();
        if (passengerName.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Passenger name cannot be empty.");
            return;
        }

        // Polymorphism — seat referenced as Bookable, not Seat
        Bookable seat = manager.getFlight(flightIdx).getSeat(seatNum);

        if (!seat.isAvailable()) {
            JOptionPane.showMessageDialog(this, "Seat " + (seatNum + 1) + " is not available.\n" + seat.getInfo());
            return;
        }

        String action = (result == 0) ? "Reserved" : "Booked";
        if (result == 0) seat.reserve(passengerName);
        else             seat.book(passengerName);

        JOptionPane.showMessageDialog(this,
                action + " successfully!\n\n" + seat.getInfo(),
                "Transaction Complete", JOptionPane.INFORMATION_MESSAGE);
    }

    // ---------------------------------------------------------------
    // Generate Report — all flights, all seats, full info + status
    // ---------------------------------------------------------------
    private void showReportDialog() {
        JTextArea area = new JTextArea(25, 55);
        area.setEditable(false);
        area.setFont(new Font("Monospaced", Font.PLAIN, 12));

        StringBuilder sb = new StringBuilder();
        sb.append("═".repeat(65)).append("\n");
        sb.append("         FLIGHT BOOKING & MANAGEMENT SYSTEM — FULL REPORT\n");
        sb.append("═".repeat(65)).append("\n\n");

        for (int i = 0; i < manager.getFlightCount(); i++) {
            Transport flight = manager.getFlight(i);
            sb.append("▶ Flight: ").append(flight.getTransportId()).append("\n");
            sb.append("─".repeat(65)).append("\n");
            sb.append(flight.getAllSeatInfo());
            sb.append("\n");
        }

        area.setText(sb.toString());
        area.setCaretPosition(0);

        JOptionPane.showMessageDialog(this, new JScrollPane(area),
                "Full Flight Report", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Frontend().setVisible(true));
    }
}
