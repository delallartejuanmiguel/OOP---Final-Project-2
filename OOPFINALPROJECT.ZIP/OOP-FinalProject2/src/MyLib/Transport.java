package MyLib;

/**
 * Abstract base class for all transport vehicles (flights, trains, etc.).
 * Enforces that every transport has an ID and can describe its seats.
 */
public abstract class Transport {
    // --- ABSTRACT CLASS: TRANSPORT ---
    
    // --- FIELDS ---
    protected String transportId;

    // --- CONSTRUCTOR ---
    public Transport(String transportId) {
        this.transportId = transportId;
    }

    // --- GETTERS ---
    public String getTransportId() {
        return transportId;
    }

    // --- ABSTRACT METHODS ---
    // Implement how they display available seats
    public abstract String getAvailableSeats();

    // Implement full seat info
    public abstract String getAllSeatInfo();

    // Implement how a seat is retrieved
    public abstract Bookable getSeat(int index);
}
