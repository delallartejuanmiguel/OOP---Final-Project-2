package MyLib;

/**
 * Flight extends the abstract Transport class.
 * It provides concrete implementations of getAvailableSeats(),
 * getAllSeatInfo(), and getSeat() — returning seats as Bookable (polymorphism).
 */
public class Flight extends Transport {
    private Bookable[] seats;  // stored as Bookable — polymorphism in action
    private int seatCount = 20;

    public Flight(String flightNumber) {
        super(flightNumber);  // calls Transport constructor
        seats = new Bookable[seatCount];

        for (int i = 0; i < seatCount; i++) {
            String seatClass = (i < 5) ? "Business" : "Economy";
            double price = seatClass.equals("Business") ? 5000 : 2000;
            seats[i] = new Seat(i + 1, seatClass, price);  // Seat stored as Bookable
        }
    }

    public String getFlightNumber() {
        return transportId;
    }

    @Override
    public Bookable getSeat(int index) {
        return seats[index];
    }

    @Override
    public String getAvailableSeats() {
        StringBuilder sb = new StringBuilder();
        for (Bookable s : seats) {
            if (s.isAvailable()) {
                sb.append(s.getInfo());
            }
        }
        return sb.toString();
    }

    @Override
    public String getAllSeatInfo() {
        StringBuilder sb = new StringBuilder();
        for (Bookable s : seats) {
            sb.append(s.getInfo());
        }
        return sb.toString();
    }
}
