package MyLib;

/**
 * Interface representing anything that can be reserved or booked.
 * Applying this to Seat allows polymorphic handling of bookable items.
 */
public interface Bookable {
    void reserve(String name);
    void book(String name);
    boolean isAvailable();
    String getInfo();
    String getSeatClass();
    double getPrice();
}
