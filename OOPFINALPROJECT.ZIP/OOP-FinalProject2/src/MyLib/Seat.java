package MyLib;

/**
 * Seat implements Bookable, enabling polymorphic handling.
 */
public class Seat implements Bookable {
    // --- CLASS: SEAT ---
    
    // --- FIELDS ---
    private int seatNumber;
    private String seatClass;
    private double price;
    private String status;
    private String passengerName;

    // --- CONSTRUCTOR ---
    public Seat(int seatNumber, String seatClass, double price) {
        this.seatNumber = seatNumber;
        this.seatClass = seatClass;
        this.price = price;
        this.status = "Available";
        this.passengerName = "";
    }

    // --- GETTERS ---
    public int getSeatNumber() {
        return seatNumber;
    }

    @Override
    public String getSeatClass() {
        return seatClass;
    }

    @Override
    public double getPrice() {
        return price;
    }

    public String getStatus() {
        return status;
    }

    @Override
    public void reserve(String name) {
        status = "Reserved";
        passengerName = name;
    }

    @Override
    public void book(String name) {
        status = "Booked";
        passengerName = name;
    }

    // --- STATUS CHECKS ---
    @Override
    public boolean isAvailable() {
        return status.equals("Available");
    }

    // --- INFO ---
    @Override
    public String getInfo() {
        String formattedPrice = "PHP " + String.format("%,.0f", price);
        return "Seat " + seatNumber +
               " | Class: " + seatClass +
               " | Price: " + formattedPrice +
               " | Status: " + status +
               " | Passenger: " + (passengerName.isEmpty() ? "N/A" : passengerName) + "\n";
    }
}