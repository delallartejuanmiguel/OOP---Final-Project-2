package MyLib;

/**
 * FlightManager
 *
 * Ensures only ONE instance of the flight data store exists across the app.
 */
public class FlightManager {
    // --- CLASS: FLIGHT MANAGER ---
    
    // --- SINGLETON INSTANCE ---
    private static FlightManager instance;  // the single instance

    // --- FIELDS ---
    private Transport[] flights;
    private final int flightCount = 5;

    // --- CONSTRUCTOR (PRIVATE) ---
    private FlightManager() {
        flights = new Transport[flightCount];
        flights[0] = new Flight("FL001");
        flights[1] = new Flight("FL002");
        flights[2] = new Flight("FL003");
        flights[3] = new Flight("FL004");
        flights[4] = new Flight("FL005");
    }

    // --- SINGLETON ACCESS --
    public static FlightManager getInstance() {
        if (instance == null) {
            instance = new FlightManager();
        }
        return instance;
    }

    // --- GETTERS ---
    public int getFlightCount() {
        return flightCount;
    }

    public Transport getFlight(int index) {
        return flights[index];
    }

    public String[] getFlightNumbers() {
        String[] numbers = new String[flightCount];
        for (int i = 0; i < flightCount; i++) {
            numbers[i] = flights[i].getTransportId();
        }
        return numbers;
    }
    
    // --- FILTER BY CLASS ---
    public String getAvailableSeatsByClass(int flightIndex, String seatClass) {
        Transport flight = flights[flightIndex];
        if (seatClass.equals("All")) {
            return flight.getAvailableSeats();
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 20; i++) {
            Bookable seat = flight.getSeat(i);
            if (seat.isAvailable() && seat.getSeatClass().equals(seatClass)) {
                sb.append(seat.getInfo());
            }
        }
        return sb.toString();
    }

    // --- FILTER BY PRICE ---
    public String getAvailableSeatsByPrice(int flightIndex, double maxPrice) {
        Transport flight = flights[flightIndex];
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 20; i++) {
            Bookable seat = flight.getSeat(i);
            if (seat.isAvailable() && seat.getPrice() <= maxPrice) {
                sb.append(seat.getInfo());
            }
        }
        return sb.toString();
    }
}
