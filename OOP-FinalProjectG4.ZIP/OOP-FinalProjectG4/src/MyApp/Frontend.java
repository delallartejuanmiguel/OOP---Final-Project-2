package MyApp;

// --- IMPORTS ---
import MyLib.Bookable;
import MyLib.FlightManager;
import MyLib.Transport;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class Frontend extends JFrame {
    // --- CLASS: FRONTEND ---
    
    private static final Color DARK_RED  = new Color(139, 0, 0);
    private static final Color YELLOW    = new Color(255, 199, 44);
    private static final Color WHITE     = Color.WHITE;
    private static final Color BLACK     = Color.BLACK;
    private static final Color LIGHT_RED = new Color(180, 30, 30);

    // --- SINGLETON MANAGER ---
    private final FlightManager manager = FlightManager.getInstance();

    // --- CONSTRUCTOR ---
    public Frontend() {
        setTitle("Flight Booking & Management System");
        setSize(520, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        showMenuPanel();
    }

    // --- STYLE COMPONENTS ---

    private JButton createMenuButton(String text, Color bg, Color fg) {
        JButton btn = new JButton(text);
        btn.setBackground(bg);
        btn.setForeground(fg);
        btn.setFont(new Font("Arial", Font.BOLD, 13));
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        Color hover = bg.brighter();
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) { btn.setBackground(hover); }
            public void mouseExited (java.awt.event.MouseEvent e) { btn.setBackground(bg); }
        });
        return btn;
    }

    private JPanel createDialogHeader(String text) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(DARK_RED);
        header.setBorder(new EmptyBorder(12, 16, 12, 16));
        JLabel label = new JLabel(text, SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 14));
        label.setForeground(YELLOW);
        header.add(label);
        JPanel accent = new JPanel();
        accent.setBackground(YELLOW);
        accent.setPreferredSize(new Dimension(0, 3));
        header.add(accent, BorderLayout.SOUTH);
        return header;
    }

    private JLabel styledLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("Arial", Font.BOLD, 12));
        lbl.setForeground(BLACK);
        return lbl;
    }

    // --- MAIN MENU ---

    private void showMenuPanel() {
        JPanel outer = new JPanel(new BorderLayout());
        outer.setBackground(WHITE);

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(DARK_RED);
        header.setBorder(new EmptyBorder(18, 20, 18, 20));
        JLabel title = new JLabel("Flight Booking & Management System", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 17));
        title.setForeground(YELLOW);
        header.add(title, BorderLayout.CENTER);
        JPanel accent = new JPanel();
        accent.setBackground(YELLOW);
        accent.setPreferredSize(new Dimension(0, 4));
        header.add(accent, BorderLayout.SOUTH);

        JPanel btnPanel = new JPanel(new GridLayout(4, 1, 0, 12));
        btnPanel.setBackground(WHITE);
        btnPanel.setBorder(new EmptyBorder(30, 50, 30, 50));

        JButton viewSeatsBtn = createMenuButton("View Available Seats", DARK_RED, YELLOW);
        JButton bookSeatBtn  = createMenuButton("Book / Reserve Seat",  DARK_RED, YELLOW);
        JButton reportBtn    = createMenuButton("Generate Report",       DARK_RED, YELLOW);
        JButton exitBtn      = createMenuButton("Exit",                  BLACK,    WHITE);

        btnPanel.add(viewSeatsBtn);
        btnPanel.add(bookSeatBtn);
        btnPanel.add(reportBtn);
        btnPanel.add(exitBtn);

        JPanel footer = new JPanel();
        footer.setBackground(DARK_RED);
        footer.setBorder(new EmptyBorder(6, 0, 6, 0));
        JLabel footerLabel = new JLabel("Group 4 - OOP Final Project", SwingConstants.CENTER);
        footerLabel.setForeground(new Color(255, 255, 255, 160));
        footerLabel.setFont(new Font("Arial", Font.PLAIN, 10));
        footer.add(footerLabel);

        outer.add(header,   BorderLayout.NORTH);
        outer.add(btnPanel, BorderLayout.CENTER);
        outer.add(footer,   BorderLayout.SOUTH);

        setContentPane(outer);
        revalidate();

        viewSeatsBtn.addActionListener(e -> showAvailableSeats());
        bookSeatBtn .addActionListener(e -> showBookingDialog());
        reportBtn   .addActionListener(e -> showReportDialog());
        exitBtn     .addActionListener(e -> System.exit(0));
    }

    // --- VIEW AVAILABLE SEATS ---

    private void showAvailableSeats() {
        JDialog dialog = new JDialog(this, "Search Available Seats", true);
        dialog.setSize(380, 280);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        String[] flightNumbers = manager.getFlightNumbers();
        JComboBox<String> flightBox = new JComboBox<>(flightNumbers);
        JComboBox<String> classBox  = new JComboBox<>(new String[]{"All", "Business", "Economy"});
        JComboBox<String> priceBox  = new JComboBox<>(new String[]{"All", "PHP 2,000", "PHP 5,000"});

        classBox.addActionListener(e -> {
            String s = (String) classBox.getSelectedItem();
            if (s.equals("Business"))     priceBox.setSelectedItem("PHP 5,000");
            else if (s.equals("Economy")) priceBox.setSelectedItem("PHP 2,000");
            else                          priceBox.setSelectedItem("All");
        });
        priceBox.addActionListener(e -> {
            String s = (String) priceBox.getSelectedItem();
            if (s.equals("PHP 5,000"))    classBox.setSelectedItem("Business");
            else if (s.equals("PHP 2,000")) classBox.setSelectedItem("Economy");
            else                          classBox.setSelectedItem("All");
        });

        JPanel form = new JPanel(new GridLayout(3, 2, 10, 12));
        form.setBackground(WHITE);
        form.setBorder(new EmptyBorder(20, 24, 10, 24));
        form.add(styledLabel("Flight Number:")); form.add(flightBox);
        form.add(styledLabel("Seat Class:"));    form.add(classBox);
        form.add(styledLabel("Ticket Price:"));  form.add(priceBox);

        JButton okBtn     = createMenuButton("Search", DARK_RED, YELLOW);
        JButton cancelBtn = createMenuButton("Cancel", BLACK, WHITE);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 10));
        btnRow.setBackground(WHITE);
        okBtn.setPreferredSize(new Dimension(110, 32));
        cancelBtn.setPreferredSize(new Dimension(110, 32));
        btnRow.add(okBtn);
        btnRow.add(cancelBtn);

        final boolean[] confirmed = {false};
        okBtn    .addActionListener(e -> { confirmed[0] = true;  dialog.dispose(); });
        cancelBtn.addActionListener(e -> dialog.dispose());

        dialog.add(createDialogHeader("Search Available Seats"), BorderLayout.NORTH);
        dialog.add(form,   BorderLayout.CENTER);
        dialog.add(btnRow, BorderLayout.SOUTH);
        dialog.setVisible(true);

        if (!confirmed[0]) return;

        int flightIdx = flightBox.getSelectedIndex();
        String selectedClass = (String) classBox.getSelectedItem();

        Transport flight = manager.getFlight(flightIdx);
        StringBuilder filtered = new StringBuilder();
        for (int i = 0; i < 20; i++) {
            Bookable seat = flight.getSeat(i);
            boolean classMatch = selectedClass.equals("All") || seat.getSeatClass().equals(selectedClass);
            if (seat.isAvailable() && classMatch)
                filtered.append(seat.getInfo());
        }

        if (filtered.length() == 0) {
            showMessage("No available seats matching your criteria.", "No Results");
            return;
        }

        String separator = "------------------------------------------------------------";
        JTextArea area = new JTextArea(15, 45);
        area.setText("Flight: " + flightNumbers[flightIdx] + "  |  Class: " + selectedClass + "\n"
                + separator + "\n" + filtered);
        area.setEditable(false);
        area.setFont(new Font("Monospaced", Font.PLAIN, 12));
        showTextDialog("Available Seats", area);
    }

    // --- BOOK / RESERVE SEAT ---

    private void showBookingDialog() {
        JDialog dialog = new JDialog(this, "Book / Reserve Seat", true);
        dialog.setSize(480, 310);  // wider so seat info doesn't truncate
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        String[] flightNumbers = manager.getFlightNumbers();
        JComboBox<String> flightBox = new JComboBox<>(flightNumbers);
        JTextField seatField  = new JTextField();
        JTextField nameField  = new JTextField();

        // Use non-editable text field instead of label so it doesn't truncate
        JTextField seatInfoField = new JTextField("Enter a seat number to see class & price.");
        seatInfoField.setEditable(false);
        seatInfoField.setFont(new Font("Arial", Font.BOLD, 11));
        seatInfoField.setForeground(Color.GRAY);
        seatInfoField.setBorder(BorderFactory.createEmptyBorder());
        seatInfoField.setBackground(WHITE);

        seatField.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            private void update() {
                try {
                    int num = Integer.parseInt(seatField.getText().trim());
                    if (num >= 1 && num <= 5) {
                        seatInfoField.setText("Class: Business  |  Price: PHP 5,000");
                        seatInfoField.setForeground(DARK_RED);
                    } else if (num >= 6 && num <= 20) {
                        seatInfoField.setText("Class: Economy  |  Price: PHP 2,000");
                        seatInfoField.setForeground(new Color(0, 130, 60));
                    } else {
                        seatInfoField.setText("Invalid seat number (1-20 only).");
                        seatInfoField.setForeground(Color.RED);
                    }
                } catch (NumberFormatException ex) {
                    seatInfoField.setText("Enter a seat number to see class & price.");
                    seatInfoField.setForeground(Color.GRAY);
                }
            }
            public void insertUpdate(javax.swing.event.DocumentEvent e)  { update(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e)  { update(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { update(); }
        });

        JPanel form = new JPanel(new GridLayout(4, 2, 10, 12));
        form.setBackground(WHITE);
        form.setBorder(new EmptyBorder(20, 24, 10, 24));
        form.add(styledLabel("Flight Number:"));      form.add(flightBox);
        form.add(styledLabel("Seat Number (1-20):")); form.add(seatField);
        form.add(styledLabel("Seat Info:"));          form.add(seatInfoField);
        form.add(styledLabel("Passenger Name:"));     form.add(nameField);

        JButton reserveBtn = createMenuButton("Reserve", DARK_RED, YELLOW);
        JButton bookBtn    = createMenuButton("Book",    DARK_RED, YELLOW);
        JButton cancelBtn  = createMenuButton("Cancel",  BLACK,    WHITE);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        btnRow.setBackground(WHITE);
        reserveBtn.setPreferredSize(new Dimension(100, 32));
        bookBtn   .setPreferredSize(new Dimension(100, 32));
        cancelBtn .setPreferredSize(new Dimension(100, 32));
        btnRow.add(reserveBtn);
        btnRow.add(bookBtn);
        btnRow.add(cancelBtn);

        final int[] choice = {-1};
        reserveBtn.addActionListener(e -> { choice[0] = 0; dialog.dispose(); });
        bookBtn   .addActionListener(e -> { choice[0] = 1; dialog.dispose(); });
        cancelBtn .addActionListener(e -> dialog.dispose());

        dialog.add(createDialogHeader("Book / Reserve Seat"), BorderLayout.NORTH);
        dialog.add(form,   BorderLayout.CENTER);
        dialog.add(btnRow, BorderLayout.SOUTH);
        dialog.setVisible(true);

        if (choice[0] < 0) return;

        int flightIdx = flightBox.getSelectedIndex();
        int seatNum;
        try {
            seatNum = Integer.parseInt(seatField.getText().trim()) - 1;
            if (seatNum < 0 || seatNum >= 20) throw new NumberFormatException();
        } catch (NumberFormatException ex) {
            showMessage("Invalid seat number. Enter 1-20.", "Error");
            return;
        }

        String passengerName = nameField.getText().trim();
        if (passengerName.isEmpty()) {
            showMessage("Passenger name cannot be empty.", "Error");
            return;
        }

        Bookable seat = manager.getFlight(flightIdx).getSeat(seatNum);
        if (!seat.isAvailable()) {
            showMessage("Seat " + (seatNum + 1) + " is not available.\n" + seat.getInfo(), "Unavailable");
            return;
        }

        String action = (choice[0] == 0) ? "Reserved" : "Booked";
        if (choice[0] == 0) seat.reserve(passengerName);
        else                seat.book(passengerName);

        showMessage(action + " successfully!\n\n" + seat.getInfo(), "Transaction Complete");
    }

    // --- GENERATE REPORT ---

    private void showReportDialog() {
    JDialog dialog = new JDialog(this, "Full Flight Report", true);
    dialog.setSize(640, 520);
    dialog.setLocationRelativeTo(this);
    dialog.setLayout(new BorderLayout());

    JPanel reportPanel = new JPanel();
    reportPanel.setLayout(new BoxLayout(reportPanel, BoxLayout.Y_AXIS));
    reportPanel.setBackground(new Color(30, 30, 30));

    for (int i = 0; i < manager.getFlightCount(); i++) {
        Transport flight = manager.getFlight(i);

        JPanel flightHeader = new JPanel(new BorderLayout());
        flightHeader.setBackground(DARK_RED);
        flightHeader.setBorder(new EmptyBorder(6, 12, 6, 12));
        flightHeader.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        JLabel flightLabel = new JLabel("Flight: " + flight.getTransportId());
        flightLabel.setFont(new Font("Arial", Font.BOLD, 13));
        flightLabel.setForeground(YELLOW);
        flightHeader.add(flightLabel, BorderLayout.WEST);
        reportPanel.add(flightHeader);

        JPanel colHeader = new JPanel(new BorderLayout());
        colHeader.setBackground(new Color(60, 0, 0));
        colHeader.setBorder(new EmptyBorder(4, 12, 4, 12));
        colHeader.setMaximumSize(new Dimension(Integer.MAX_VALUE, 26));
        JLabel colLabel = new JLabel("  Seat   Class         Price        Status       Passenger");
        colLabel.setFont(new Font("Monospaced", Font.BOLD, 11));
        colLabel.setForeground(YELLOW);
        colHeader.add(colLabel);
        reportPanel.add(colHeader);

        for (int j = 0; j < 20; j++) {
            Bookable seat = flight.getSeat(j);
            String status = seat.isAvailable() ? "Available" : (seat.getInfo().contains("Reserved") ? "Reserved" : "Booked");
            String line = seat.getInfo().replace("\n", "");

            JPanel row = new JPanel(new BorderLayout());
            boolean isEven = j % 2 == 0;
            row.setBackground(isEven ? new Color(40, 40, 40) : new Color(50, 50, 50));
            row.setBorder(new EmptyBorder(4, 12, 4, 12));
            row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 24));

            JLabel rowLabel = new JLabel(line);
            rowLabel.setFont(new Font("Monospaced", Font.PLAIN, 11));

            if (seat.isAvailable()) {
                rowLabel.setForeground(new Color(100, 220, 120)); // green = available
            } else if (line.contains("Reserved")) {
                rowLabel.setForeground(YELLOW);                   // yellow = reserved
            } else {
                rowLabel.setForeground(new Color(255, 100, 100)); // red = booked
            }

            row.add(rowLabel);
            reportPanel.add(row);
        }

        JPanel spacer = new JPanel();
        spacer.setBackground(new Color(30, 30, 30));
        spacer.setPreferredSize(new Dimension(0, 8));
        spacer.setMaximumSize(new Dimension(Integer.MAX_VALUE, 8));
        reportPanel.add(spacer);
    }
    
        JPanel legend = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 8));
        legend.setBackground(new Color(30, 30, 30));
        JLabel avail    = new JLabel("● Available");
        JLabel reserved = new JLabel("● Reserved");
        JLabel booked   = new JLabel("● Booked");
        avail   .setForeground(new Color(100, 220, 120));
        reserved.setForeground(YELLOW);
        booked  .setForeground(new Color(255, 100, 100));
        avail.setFont(new Font("Arial", Font.BOLD, 11));
        reserved.setFont(new Font("Arial", Font.BOLD, 11));
        booked.setFont(new Font("Arial", Font.BOLD, 11));
        legend.add(avail); legend.add(reserved); legend.add(booked);

        JButton closeBtn = createMenuButton("Close", DARK_RED, YELLOW);
        closeBtn.setPreferredSize(new Dimension(110, 32));
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 8));
        btnRow.setBackground(new Color(30, 30, 30));
        btnRow.add(closeBtn);
        closeBtn.addActionListener(e -> dialog.dispose());

        JPanel bottom = new JPanel(new BorderLayout());
        bottom.setBackground(new Color(30, 30, 30));
        bottom.add(legend, BorderLayout.CENTER);
        bottom.add(btnRow, BorderLayout.SOUTH);

        dialog.add(createDialogHeader("Full Flight Report"), BorderLayout.NORTH);
        dialog.add(new JScrollPane(reportPanel,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER), BorderLayout.CENTER);
        dialog.add(bottom, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }


    // --- MESSAGES / DIALOGS ---

    private void showMessage(String message, String title) {
        JDialog dialog = new JDialog(this, title, true);
        dialog.setSize(360, 210);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        JLabel msg = new JLabel("<html><div style='text-align:center;color:black;'>"
                + message.replace("\n", "<br>") + "</div></html>", SwingConstants.CENTER);
        msg.setFont(new Font("Arial", Font.PLAIN, 12));
        msg.setForeground(BLACK);
        msg.setBorder(new EmptyBorder(16, 20, 10, 20));

        JPanel center = new JPanel(new BorderLayout());
        center.setBackground(WHITE);
        center.add(msg, BorderLayout.CENTER);

        JButton okBtn = createMenuButton("OK", DARK_RED, YELLOW);
        okBtn.setPreferredSize(new Dimension(100, 32));
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 10));
        btnRow.setBackground(WHITE);
        btnRow.add(okBtn);
        okBtn.addActionListener(e -> dialog.dispose());

        dialog.add(createDialogHeader(title), BorderLayout.NORTH);
        dialog.add(center,  BorderLayout.CENTER);
        dialog.add(btnRow,  BorderLayout.SOUTH);
        dialog.getContentPane().setBackground(WHITE);
        dialog.setVisible(true);
    }

    private void showTextDialog(String title, JTextArea area) {
        JDialog dialog = new JDialog(this, title, true);
        dialog.setSize(620, 440);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        area.setBackground(new Color(30, 30, 30));
        area.setForeground(new Color(200, 200, 200));
        area.setCaretColor(WHITE);

        JButton closeBtn = createMenuButton("Close", DARK_RED, YELLOW);
        closeBtn.setPreferredSize(new Dimension(110, 32));
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 10));
        btnRow.setBackground(new Color(30, 30, 30));
        btnRow.add(closeBtn);
        closeBtn.addActionListener(e -> dialog.dispose());

        JScrollPane scroll = new JScrollPane(area);
        scroll.getViewport().setBackground(new Color(30, 30, 30));

        dialog.add(createDialogHeader(title), BorderLayout.NORTH);
        dialog.add(scroll,  BorderLayout.CENTER);
        dialog.add(btnRow,  BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    // --- ENTRY POINT ---
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Frontend().setVisible(true));
    }
}