package MyLib;

/**
 * Abstract base class for all transport vehicles (flights, trains, etc.).
 * Enforces that every transport has an ID and can describe its seats.
 */
public abstract class Transport {
    protected String transportId;

    public Transport(String transportId) {
        this.transportId = transportId;
    }

    public String getTransportId() {
        return transportId;
    }

    // Subclasses must implement how they display available seats
    public abstract String getAvailableSeats();

    // Subclasses must implement full seat info
    public abstract String getAllSeatInfo();

    // Subclasses must implement how a seat is retrieved
    public abstract Bookable getSeat(int index);
}
