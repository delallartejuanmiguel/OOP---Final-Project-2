package MyLib;

/**
 * Seat implements Bookable, enabling polymorphic handling.
 * E.g., Bookable b = new Seat(...) is valid.
 */
public class Seat implements Bookable {
    private int seatNumber;
    private String seatClass;
    private double price;
    private String status;
    private String passengerName;

    public Seat(int seatNumber, String seatClass, double price) {
        this.seatNumber = seatNumber;
        this.seatClass = seatClass;
        this.price = price;
        this.status = "Available";
        this.passengerName = "";
    }

    public int getSeatNumber() {
        return seatNumber;
    }

    @Override
    public String getSeatClass() {
        return seatClass;
    }

    @Override
    public double getPrice() {
        return price;
    }

    public String getStatus() {
        return status;
    }

    @Override
    public void reserve(String name) {
        status = "Reserved";
        passengerName = name;
    }

    @Override
    public void book(String name) {
        status = "Booked";
        passengerName = name;
    }

    @Override
    public boolean isAvailable() {
        return status.equals("Available");
    }

    @Override
    public String getInfo() {
        return "Seat " + seatNumber +
                " | Class: " + seatClass +
                " | Price: " + price +
                " | Status: " + status +
                " | Passenger: " + passengerName + "\n";
    }
}
