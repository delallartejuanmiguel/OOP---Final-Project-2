package MyLib;

/**
 * Interface representing anything that can be reserved or booked.
 * Polymorphic handling of bookable items for the Seat classes.
 */
public interface Bookable {
    // --- INTERFACE: BOOKABLE ---
    
    // --- BOOKING ACTIONS ---
    void reserve(String name);
    void book(String name);
    
    // --- STATUS CHECKS ---
    boolean isAvailable();
    
    // --- GETTERS ---
    String getInfo();
    String getSeatClass();
    double getPrice();
}
