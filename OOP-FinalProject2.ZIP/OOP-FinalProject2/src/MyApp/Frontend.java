package MyApp;
    import MyLib.Flight;
    import MyLib.Seat;

    import javax.swing.*;
    import java.awt.*;

public class Frontend extends JFrame {

    private Flight[] flights;
    private int flightCount = 5;

    public Frontend() {
        setTitle("Flight Booking System");
        setSize(500, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        setupFlights();
        showMenuPanel();
    }

    private void setupFlights() {
        flights = new Flight[flightCount];
        flights[0] = new Flight("FL001");
        flights[1] = new Flight("FL002");
        flights[2] = new Flight("FL003");
        flights[3] = new Flight("FL004");
        flights[4] = new Flight("FL005");
    }

    private void showMenuPanel() {
        JPanel panel = new JPanel(new GridLayout(4, 1, 10, 10));
        JButton viewSeatsBtn = new JButton("View Available Seats");
        JButton bookSeatBtn = new JButton("Book/Reserve Seat");
        JButton reportBtn = new JButton("Generate Report");
        JButton exitBtn = new JButton("Exit");

        panel.add(viewSeatsBtn);
        panel.add(bookSeatBtn);
        panel.add(reportBtn);
        panel.add(exitBtn);

        setContentPane(panel);
        revalidate();

        viewSeatsBtn.addActionListener(e -> showAvailableSeats());
        bookSeatBtn.addActionListener(e -> showBookingDialog());
        reportBtn.addActionListener(e -> showReportDialog());
        exitBtn.addActionListener(e -> System.exit(0));
    }

    private void showAvailableSeats() {
        JComboBox<String> flightBox = new JComboBox<>();
        for (int i = 0; i < flightCount; i++) {
            flightBox.addItem(flights[i].getFlightNumber());
        }

        int result = JOptionPane.showConfirmDialog(this, flightBox,
                "Select Flight", JOptionPane.OK_CANCEL_OPTION);

        if (result == JOptionPane.OK_OPTION) {
            int idx = flightBox.getSelectedIndex();
            String info = flights[idx].getAvailableSeats();

            JTextArea area = new JTextArea(15, 40);
            area.setText(info);
            area.setEditable(false);

            JOptionPane.showMessageDialog(this, new JScrollPane(area),
                    "Available Seats", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void showBookingDialog() {
        JComboBox<String> flightBox = new JComboBox<>();
        for (int i = 0; i < flightCount; i++) {
            flightBox.addItem(flights[i].getFlightNumber());
        }

        JTextField seatField = new JTextField();
        JTextField nameField = new JTextField();
        String[] options = {"Reserve", "Book"};

        JPanel panel = new JPanel(new GridLayout(4, 2, 5, 5));
        panel.add(new JLabel("Flight:"));
        panel.add(flightBox);
        panel.add(new JLabel("Seat Number:"));
        panel.add(seatField);
        panel.add(new JLabel("Passenger Name:"));
        panel.add(nameField);

        int result = JOptionPane.showOptionDialog(this, panel,
                "Seat Booking", JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE, null,
                options, options[0]);

        if (result >= 0) {
            int flightIdx = flightBox.getSelectedIndex();
            int seatNum;

            try {
                seatNum = Integer.parseInt(seatField.getText()) - 1;
                if (seatNum < 0 || seatNum >= 20) throw new NumberFormatException();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Invalid seat number.");
                return;
            }

            Seat seat = flights[flightIdx].getSeat(seatNum);

            if (!seat.isAvailable()) {
                JOptionPane.showMessageDialog(this, "Seat not available.");
                return;
            }

            if (result == 0) seat.reserve(nameField.getText());
            else seat.book(nameField.getText());

            JOptionPane.showMessageDialog(this, "Transaction successful.");
        }
    }

    private void showReportDialog() {
        JTextArea area = new JTextArea(20, 40);
        area.setEditable(false);

        for (int i = 0; i < flightCount; i++) {
            area.append("Flight: " + flights[i].getFlightNumber() + "\n");
            area.append(flights[i].getAllSeatInfo());
            area.append("-----------------------------\n");
        }

        JOptionPane.showMessageDialog(this, new JScrollPane(area),
                "Flight Report", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Frontend().setVisible(true));
    }
}
