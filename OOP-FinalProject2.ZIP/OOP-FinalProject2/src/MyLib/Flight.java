package MyLib;

public class Flight {
    private String flightNumber;
    private Seat[] seats;
    private int seatCount = 20;

    public Flight(String flightNumber) {
        this.flightNumber = flightNumber;
        seats = new Seat[seatCount];

        for (int i = 0; i < seatCount; i++) {
            String seatClass = (i < 5) ? "Business" : "Economy";
            double price = (seatClass.equals("Business")) ? 5000 : 2000;
            seats[i] = new Seat(i + 1, seatClass, price);
        }
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public Seat getSeat(int index) {
        return seats[index];
    }

    public String getAvailableSeats() {
        StringBuilder sb = new StringBuilder();
        for (Seat s : seats) {
            if (s.isAvailable()) {
                sb.append(s.getInfo());
            }
        }
        return sb.toString();
    }

    public String getAllSeatInfo() {
        StringBuilder sb = new StringBuilder();
        for (Seat s : seats) {
            sb.append(s.getInfo());
        }
        return sb.toString();
    }
}
