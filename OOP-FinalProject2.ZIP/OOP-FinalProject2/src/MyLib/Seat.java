package MyLib;

public class Seat {
    private int seatNumber;
    private String seatClass;
    private double price;
    private String status;
    private String passengerName;

    public Seat(int seatNumber, String seatClass, double price) {
        this.seatNumber = seatNumber;
        this.seatClass = seatClass;
        this.price = price;
        this.status = "Available";
        this.passengerName = "";
    }

    public int getSeatNumber() {
        return seatNumber;
    }

    public String getSeatClass() {
        return seatClass;
    }

    public double getPrice() {
        return price;
    }

    public String getStatus() {
        return status;
    }

    public void reserve(String name) {
        status = "Reserved";
        passengerName = name;
    }

    public void book(String name) {
        status = "Booked";
        passengerName = name;
    }

    public boolean isAvailable() {
        return status.equals("Available");
    }

    public String getInfo() {
        return "Seat " + seatNumber +
                " | Class: " + seatClass +
                " | Price: " + price +
                " | Status: " + status +
                " | Passenger: " + passengerName + "\n";
    }
}
